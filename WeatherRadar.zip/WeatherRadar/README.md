# WeatherRadar
## Dev Team 4: Azmi Barakat, Alan Martinez-Lopez, Joseph Villarrubia, Otto Zimmerman
WeatherRadar Repository that does the following:

This repository tracks the versions of the WeatherRadar application. Dev Team 4 will use this for Software Configuration Management and Version Control.

To access the WeatherRadar appplication, click [here.](https://am26001.github.io/WeatherRadar/index.html)
